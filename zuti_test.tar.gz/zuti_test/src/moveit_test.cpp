#include <moveit/move_group_interface/move_group.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>

#include <moveit_visual_tools/moveit_visual_tools.h>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "move_test");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(1);
  spinner.start();
  sleep(5.0);
 
  // Setting the move_groupfor planning group
  moveit::planning_interface::MoveGroup group("arm");

  // Adding the planning scene
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface; 
  
  // Create the publisher for visualizing plans 
  /*ros::Publisher display_publisher = node_handle.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
  moveit_msgs::DisplayTrajectory display_trajectory;

  // Name of the reference frame
  ROS_INFO("Reference frame: %s", group.getPlanningFrame().c_str());

  // Getting end-effector link name
  ROS_INFO("End Effector link name: %s", group.getEndEffectorLink().c_str());

  // Setting the pose tolerance
  group.setGoalPositionTolerance(0.000001);

  // Setting the Orientation tolerance
  group.setGoalOrientationTolerance(0.00001);
  
  // Setting goal joint tolerance
  group.setGoalJointTolerance(0.000001);*/

  // Planning to a pre-defined pose
  std::vector<double> joint_positions;
  group.getCurrentState()->copyJointGroupPositions(group.getCurrentState()->getRobotModel()->getJointModelGroup(group.getName()), joint_positions);
  joint_positions[0] = 0.0;
  joint_positions[1] = 0.733038;
  joint_positions[2] = 0.0;
  joint_positions[3] = 1.57;
  joint_positions[4] = 0.0;
  joint_positions[5] = 0.872665;
  joint_positions[6] = 0;
  group.setJointValueTarget(joint_positions);
  
  // Visualizing the plan
  moveit::planning_interface::MoveGroup::Plan my_plan;
  
  bool success = group.plan(my_plan);
  
  ROS_INFO("Visualizing plan 1 (pose goal) %s", success ? "": "FAILED");
  sleep(1.0);
  group.move();
  sleep(5.0);
  
  //  Ending the process
  ros::shutdown();
  return 0;
}  
  

#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include <iostream>
#include <sstream>
#include "basics/my_msg.h"


int main(int argc, char **argv)
{
    ros::init(argc,argv,"publisher");
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<basics::my_msg>("/msg",10);
    ros::Rate loop_rate(10);
    
    int count = 0;
    basics::my_msg msg;
    
    while(ros::ok())
    {
        msg.greeting = "piyush";
        msg.number = count;
        
        ROS_INFO("%d",msg.number);
        ROS_INFO("%s",msg.greeting.c_str());
        
        pub.publish(msg);
        
        ros::spinOnce();
        
        loop_rate.sleep();
        
        ++count;
    }
return 0;
}

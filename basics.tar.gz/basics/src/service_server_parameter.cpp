#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include <iostream>
#include <sstream>
#include "basics/my_srv.h"

#include <boost/ref.hpp>



using namespace std;



bool service_callback(basics::my_srv::Request  &req,
         				   basics::my_srv::Response &res,int a)
{

  std::stringstream ss;
  ss << "Received  Here";
  res.out = ss.str();

  ROS_INFO("From Client  [%s], Server says [%s]",req.in.c_str(),res.out.c_str());
  ROS_INFO("From Client  [%d]",a);

  return true;
}




int main(int argc, char **argv)
{
  ros::init(argc, argv, "service_server");
  ros::NodeHandle n;
  int a = 0;
  ros::ServiceServer service = n.advertiseService<basics::my_srv::Request,
  												  basics::my_srv::Response>
  												  	("service", boost::bind(service_callback,_1,_2,a));
  ROS_INFO("Ready to receive from client.");
  ros::spin();

  return 0;
}


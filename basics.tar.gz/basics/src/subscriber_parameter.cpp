#include "ros/ros.h"
#include "std_msgs/Int32.h"
#include <iostream>
#include <sstream>
#include "basics/my_msg.h"
#include <boost/ref.hpp>

void number_callback(const basics::my_msg::ConstPtr& msg,int a)
{
	//ROS_INFO("Recieved  greeting [%s]",msg->greeting.c_str());
	//ROS_INFO("Recieved  [%d]",msg->number);
		ROS_INFO("Recieved  [%d]",a);
}


int main(int argc, char **argv)
{
    ros::init(argc, argv,"subscriber");
	//Created a nodehandle object
	ros::NodeHandle nh;
	//Create a publisher object
	int a = 2;
	ros::Subscriber sub = nh.subscribe<basics::my_msg>("/msg",10,boost::bind(number_callback,_1,a));
	//Spinning the node
	ros::spin();
	return 0;
}
